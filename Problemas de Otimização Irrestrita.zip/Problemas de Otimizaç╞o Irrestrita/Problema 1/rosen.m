% FUN��O ROSENBROCK [1]

% Dimens�es     -> n=2, m=2              
% Ponto Inicial -> x=(-1.2,1)  
% Minimizador   -> f=0 em (1,1)              

function [fvec,J,f] = rosen(n,m,x,option)  
if (option==1 | option==3)
        fvec = @(x)[10*(x(2)-x(1)^2) 
                           (1-x(1))] ; 
               f = @(x)(10*(x(2)-x(1)^2))^2+(1-x(1))^2;
end        
if (option==2 | option==3)
        J    = @(x) [-20*x(1)  10
                      -1        0] ; 

end
%HESSIANA DA FUN��O BROWN BADLY SCALED FUNCTION [4]:

function [H] = hessiana(x)
   H = [2*x(2)^2+2, 4*x(1)*x(2)-4;
        4*x(1)*x(2)-4 2*x(1)^2+2];
end

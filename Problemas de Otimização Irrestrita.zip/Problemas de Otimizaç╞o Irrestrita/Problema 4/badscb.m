%FUN��O BROWN BADLY SCALED FUNCTION [4]:

% Dimens�es     -> n=2, m=3              
% Ponto inicial -> x=(1,1)  
% Minimizador   -> f=0 em (1e+6,2e-6)        

function [fvec,J,f] = badscb(n,m,x,option)  
if (option==1 | option==3)
        fvec = @(x)[  x(1)-10^6
                  x(2)-(2e-6)
                  x(1)*x(2)-2  ]  ;
              f = @(x) (x(1)-10^6)^2 + (x(2)-(2e-6))^2 + (x(1)*x(2)-2)^2;
end;        
if (option==2 | option==3)
        J    = @(x) [  1      0
                       0      1
                      x(2)   x(1)  ] ;
end;

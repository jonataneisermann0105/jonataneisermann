%M�TODO DO GRADIENTE APLICADO � FUN��O BEALE [5]:

n          = 2;
m          = 3;
option     = 3;
x          = [1,1]';
[fvec,J,f] = beale(n,m,x,option); 
p          = -2*[J(x)]'*fvec(x);
c1         = 0.0001;
k          = 0;
tol        = 10^(-4);

while norm(p) >= tol
    
    alpha = 1;
    
    %Backtracking
    while  f(x+alpha*p) > f(x)+c1*alpha*p'*p
        alpha = alpha*0.9;
    end

  x          = x+alpha*p
  [fvec,J,f] = beale(n,m,x,option);
  p          = -2*[J(x)]'*fvec(x);
  k          = k+1;
  
end
x

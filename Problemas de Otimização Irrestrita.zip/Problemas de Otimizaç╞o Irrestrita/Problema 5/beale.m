% FUN��O BEALE [5]

% Dimens�es -> n=2, m=3              
% Ponto Inicial -> x=(1,1) 
% Minimizador -> f=0 em (3,0.5)            

function [fvec,J,f] = beale(n,m,x,option)

if (option==1 | option==3)
        fvec = @(x)[  1.5-x(1)*(1-x(2))
                  2.25-x(1)*(1-x(2)^2)
                  2.625-x(1)*(1-x(2)^3)  ]; 
              f = @(x)(1.5-x(1)*(1-x(2)))^2 + (2.25-x(1)*(1-x(2)^2))^2 + (2.625-x(1)*(1-x(2)^3))^2;
end;        
if (option==2 | option==3)
        J    = @(x)[  -(1-x(2))      x(1)
                    -(1-x(2)^2)    x(1)*2*x(2)
                    -(1-x(2)^3)    x(1)*3*x(2)^2  ]; 
        
end;

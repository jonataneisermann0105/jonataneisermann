%M�TODO DE REGI�O DE CONFIAN�A APLICADO � FUN��O WOOD [14]:

%Inicializa��o:
option     = 3;
n          = 4;
m          = 6;
x          = [-3,-1,-3,-1]';
[fvec,J,f] = wood(n,m,x,option);
g          = 2*[J(x)]'*fvec(x);
[H]        = hessiana(x);
r          = 1;
tol        = 1e-4;
eta1       = 0.01;                    
eta2       = 0.9;
gamma1     = 0.5;
gamma2     = 0.5;                                        

%M�todo:
k = 0;
while norm(g) > tol
    
    % Calcular s usando moresorensen
    [s] = moresorensen( g, H, r, tol );
    fred = f(x)-f(x+s);
    mred = -s'*g-(0.5)*s'*H*s;                  
    p    = fred/mred;

    %C�lculo dos novos valores de x e atualiza��o da Regi�o de Confian�a:
    if p >= eta1
        % Aceitar o ponto
        x          = x+s
        [fvec,J,f] = wood(n,m,x,option);
        g          = 2*[J(x)]'*fvec(x);
        [H]        = hessiana(x);
    end
    
    %Atualiza��o da regi�o de confian�a:
    if p < eta1
        r = r*gamma1;
    elseif p > eta2
        r = 2*r;
    end

    %Continua��o do processo de Itera��es: 
    k = k+1;
   
end

% Resultado final:
x

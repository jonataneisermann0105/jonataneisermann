%M�TODO DO GRADIENTE APLICADO � FUN��O WOOD [14]:

option     = 3;
n          = 4;
m          = 6;
x          = [-3,-1,-3,-1]';
[fvec,J,f] = wood(n,m,x,option); 
p          = -2*[J(x)]'*fvec(x);
c1         = 0.0001;
k          = 0;
tol        = 10^(-4);

while norm(p) >= tol
    
    alpha = 1;
    
    %Backtracking
    while  f(x+alpha*p) > f(x)+c1*alpha*p'*p
        alpha = alpha*0.9;
    end

  x          = x+alpha*p
  [fvec,J,f] = wood(n,m,x,option);
  p          = -2*[J(x)]'*fvec(x);
  k          = k+1;
  
end
x

% M�TODO DE NEWTON APLICADO � FUN��O WOOD [14]:
 
%Entradas do m�todo:
a0     = 1; 
r      = 0.9;
c      = 0.0001;
tol    = 1e-4;
option = 3;
n      = 4;
m      = 6;
x      = [-3,-1,-3,-1]';

%Fun��o e Gradiente Wood
[fvec,J,f] = wood(n,m,x,option);
  
g = 2*[J(x)]'*fvec(x);

%Hessiana Wood
[H] = hessiana(x);    

%M�todo:

k = 0;
while norm(g)>tol
    det(H)
    eigs(H)
    pause
    p = H\-g;
    
     %Garantia de Dire��o de Descida
    if g'*p >=0 
        p = -g;
    end
   
    %Condi��o de Armijo
    a = a0;
    j = 1;
    while (f(x+a*p)>=f(x)+c*a*g'*p)
        a=r*a;
        j = j + 1;  
    end

    %C�lculo dos novos valores
    x          = x+a*p;
    [fvec,J,f] = wood(n,m,x,option);
    g          = 2*[J(x)]'*fvec(x);
    [H]        = hessiana(x);
    k          = k + 1;
end

disp(['O metodo convergiu em ', num2str(k), ' iteracoes.'])
disp('Solucao: ')
x

%FUN��O WOOD [14]:

function [fvec,J,f] = wood(n,m,x,option)

% Dimens�es:      n=4   m=6
% Ponto Inicial:  (-3,-1,-3,-1)
% Minimizador:    f=0 em (1,1,1,1)

if((option==1)|(option ==3))

fvec =  @(x) [  10*(x(2)-x(1)^2)
            1-x(1)
            sqrt(90)*(x(4)-x(3)^2)
            1-x(3)
            sqrt(10)*(x(2)+x(4)-2)
            (1/sqrt(10))*(x(2)-x(4))  ];
        f = @(x)(10*(x(2)-x(1)^2))^2 + (1-x(1))^2 + (sqrt(90)*(x(4)-x(3)^2))^2 + (1-x(3))^2 + (sqrt(10)*(x(2)+x(4)-2))^2 + ((1/sqrt(10))*(x(2)-x(4)))^2;
end

if ((option==2)|(option==3))
J    = @(x) [  -20*x(1)       10        0            0
            -1     	   0         0            0
             0             0   -2*sqrt(90)*x(3)  sqrt(90)    
             0             0        -1            0
             0           sqrt(10)    0           sqrt(10)
             0         1/sqrt(10)    0          -1/sqrt(10)  ] ;

end;

if((option<1)|(option>3))
        disp('Error: Option value for WOOD.M is either <1 or >3');
end;
       
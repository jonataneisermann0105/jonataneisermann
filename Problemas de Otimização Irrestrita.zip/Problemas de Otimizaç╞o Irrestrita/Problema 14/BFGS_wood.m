%M�TODO QUASE-NEWTON BFGS APLICADO � FUN��O WOOD [14]:

%Inicializa��o:
option     = 3;
n          = 4;
m          = 6;
x          = [-3,-1,-3,-1]';
[fvec,J,f] = wood(n,m,x,option);
g          = 2*[J(x)]'*fvec(x);
a0         = 1;
r          = 0.9;
c          = 0.0001;                                                         %Constante da Condi��o de Armijo
H          = eye(n,n);                                                       %Aproxima��o da Inversa;
tol        = 1e-4;                                                           %Toler�ncia;
k          = 0;

%M�todo:
while norm(g)>tol
    p = -H*g;
    
    %Condi��o de Armijo
    a = a0;
    while (f(x+a*p) > f(x)+c*a*g'*p)
        a = r*a;
    end
    
    %C�lculo dos novos valores
    x          = x+a*p
    [fvec,J,f] = wood(n,m,x,option);
    s          = a*p;
    g1         = 2*[J(x)]'*fvec(x);
    y          = g1-g;
    t          = 1/(y'*s);
    H          = (eye(n,n)-t*s*y')*H*(eye(n,n)-t*y*s')+t*s*s';
    g          = g1;
    k          = k+1;
end
  x  

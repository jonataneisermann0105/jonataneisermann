%HESSIANA DA FUN��O FREUDENSTEIN E ROTH [2]
function [H] = hessiana(x)
   H = [0, -12*x(2)+8;
    -12*x(2)+8, 120*x(2)^3-456*x(2)^2+240*x(2)+244-12*x(1)];
end

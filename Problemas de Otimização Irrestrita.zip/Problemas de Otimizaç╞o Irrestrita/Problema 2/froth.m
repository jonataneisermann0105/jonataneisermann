% FUN��O FREUDENSTEIN E ROTH [2]

% Dimens�es     -> n=2, m=2                           
% Ponto Inicial -> x=(0.5,-2)            
% Minimizador   -> f=0 em (5,4)                           
%                  f=48.9842... em (11.41...,-0.8968...)  

function [fvec,J,f] = froth(n,m,x,option)

if (option==1 | option==3)
        fvec = @(x)[ -13+x(1)+((5-x(2))*x(2)-2)*x(2)
                   -29+x(1)+((x(2)+1)*x(2)-14)*x(2) ]; 
             f = @(x) (-13+x(1)+((5-x(2))*x(2)-2)*x(2))^2 + (-29+x(1)+((x(2)+1)*x(2)-14)*x(2))^2;
end        
if (option==2 | option==3)
        J    = @(x)[ 1       10*x(2)-3*x(2)^2-2
                     1       3*x(2)^2+2*x(2)-14  ] ;
        
end

%HESSIANA DA FUN��O LINEAR - POSTO COMPLETO [32]

function [H] = hessiana(x)
H = [2, 0, 0;
     0, 2, 0
     0, 0, 2]; 
end
%FUN��O LINEAR - POSTO COMPLETO [32]

function [fvec,J,f]= lin(n,m,x,option)

%Dimens�es:      n=3,      m=3
%Ponto Inicial: (1,...,1)
%Minimizador:    f=m-n em (-1,...,-1)


J=zeros(m,n);
for i=1:n

    sum1=sum(x);
        
    if((option==1)|(option==3))
        fvec(i)= x(i)-(2/m)*sum1-1;
    end

    if((option==2)|(option==3))
        for j=1:n
           if i==j
                J(i,j)=1-(2/m);
           else J(i,j)=-(2/m);
           end
        end
    end
end

for i=n+1:m
        
    if((option==1)|(option==3))
        fvec(i)= -(2/m)*sum1-1;
    end;

    if((option==2)|(option==3))
        for j=1:n
                J(i,j)=-(2/m);
        end;
    end;
end;
       
fvec=fvec';
f   =fvec'*fvec;
end

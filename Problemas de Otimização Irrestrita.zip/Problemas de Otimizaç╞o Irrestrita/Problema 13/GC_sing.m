%M�TODO DO GRADIENTE CONJUGADO N�O-LINEAR APLICADO � FUN��O POWELL SINGULAR [13]:

option     = 3;
n          = 4;
m          = 4;
x          = [3,-1,0,1]';
[fvec,J,f] = sing(n,m,x,option);
g          = 2*[J(x)]'*fvec(x);
p          = -g;
tol        = 1e-4;
k          = 0;
a0         = 1;
c          = 0.0001; 
r          = 0.9;

while norm (g) > tol
    
    %Busca Linear / Condi��o de Armijo
    a = a0;
     while (f(x+a*p) > f(x)+c*a*g'*p)
        a = r*a;
    end
    
    %C�lculo dos novos valores:
    x          = x + a*p;
    [fvec,J,f] = sing(n,m,x,option);
    g1         = 2*[J(x)]'*fvec(x);
    B          = (g1'*g1)/(g'*g);
    p          = -g1+B*p;
    g          = g1;
    k          = k+1;
end
x
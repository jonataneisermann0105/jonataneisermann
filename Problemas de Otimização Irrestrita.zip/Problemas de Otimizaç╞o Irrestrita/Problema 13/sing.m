% FUN��O POWELL SINGULAR  [13]

function [fvec,J,f] = sing(n,m,x,option)

% Dimens�es:     n=4    m=4
% Ponto Inicial: (3,-1,0,1);
% Minimizador:   f=0 em (0,0,0,0);

if((option ==1 )|(option ==3))

        fvec =  @(x)[  x(1)+10*x(2)
          	   sqrt(5)*(x(3)-x(4))
          	   (x(2)-2*x(3))^2
                   sqrt(10)*((x(1)-x(4))^2)  ] ;
               f = @(x) (x(1)+10*x(2))^2 + (sqrt(5)*(x(3)-x(4)))^2 + ((x(2)-2*x(3))^2)^2 + (sqrt(10)*((x(1)-x(4))^2))^2;
end

if((option==2)|(option==3))

J    = @(x) [  1                           10       0                            0
           0                            0       sqrt(5)               -sqrt(5)
           0              2*(x(2)-2*x(3))      -4*(x(2)-2*x(3))              0 
           2*sqrt(10)*(x(1)-x(4))       0       0      -2*sqrt(10)*(x(1)-x(4))];

end
end
% M�TODO DE NEWTON APLICADO � FUN��O LINEAR - POSTO 1 [33]
 
%Entradas do m�todo:
r      = 0.9;
c1     = 0.0001;
tol    = 1e-4;
n      = 3;
m      = 3;
x      = [1,1,1]';
option = 3;

%Fun��o:
[fvec,J,f] = lin1(n,m,x,option);
g = 2*[J]'*fvec;

%Hessiana:
[H] = hessiana(x);    

%M�todo:

k = 0;
while norm(g)>tol

    p = H\-g;
   
    %Garantia de Dire��o de Descida
    if g'*p >=0 
        p = -g;
    end
    
    %Condi��o de Armijo
    alpha = 1;
    
    %Valores antigos
    [fvec,J,f] = lin1(n,m,x,option);
    fold       = f;
    
    %Valores Novos
    [fvec,J,f] = lin1(n,m,x+alpha*p,option);
    fnew       = f;
    
         while  fnew > fold + c1*alpha*p'*p
            alpha      = alpha*0.9
            [fvec,J,f] = lin1(n,m,x+alpha*p,option);
            fnew       = f;
         end

    %C�lculo dos novos valores
    x          = x+alpha*p
    [fvec,J,f] = lin1(n,m,x,option);
    g          = 2*[J]'*fvec;
    [H]        = hessiana(x);
    k          = k + 1;
    pause
end

disp(['O metodo convergiu em ', num2str(k), ' iteracoes.'])
disp('Solucao: ')
x
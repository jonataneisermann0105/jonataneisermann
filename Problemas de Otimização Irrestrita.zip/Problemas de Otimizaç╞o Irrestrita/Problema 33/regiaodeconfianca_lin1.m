%M�TODO DE REGI�O DE CONFIAN�A APLICADO � FUN��O LINEAR - POSTO 1 [33]:

%Inicializa��o:
n          = 3;
m          = 3;
x          = [1,1,1]';
option     = 3;
[fvec,J,f] = lin1(n,m,x,option);
g          = 2*[J]'*fvec;
[H]        = hessiana(x);
r          = 1;
tol        = 1e-4;
eta1       = 0.01;                    
eta2       = 0.9;
gamma1     = 0.5;
gamma2     = 0.5;                                        

%M�todo:
k = 0;
while norm(g) > tol
    
    % Calcular s usando moresorensen
    [s]        = moresorensen( g, H, r, tol );
    [fvec,J,f] = lin1(n,m,x,option);
    f1         = f;
    [fvec,J,f] = lin1(n,m,x+s,option);
    f2         = f;
    fred       = f1-f2;
    mred       = -s'*g-(0.5)*s'*H*s;                  
    p          = fred/mred;

    %C�lculo dos novos valores de x e atualiza��o da Regi�o de Confian�a:
    if p >= eta1
        % Aceitar o ponto
        x          = x+s
        [fvec,J,f] = lin1(n,m,x,option);
        g          = 2*[J]'*fvec;
        [H]        = hessiana(x);
    end
    
    %Atualiza��o da regi�o de confian�a:
    if p < eta1
        r = r*gamma1;
    elseif p > eta2
        r = 2*r;
    end

    %Continua��o do processo de Itera��es: 
    k = k+1;
   
end

% Resultado final:
x

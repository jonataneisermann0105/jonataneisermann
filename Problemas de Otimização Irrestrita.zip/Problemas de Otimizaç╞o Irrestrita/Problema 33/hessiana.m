%HESSIANA DA FUN��O LINEAR - POSTO 1 [33]

function [H] = hessiana(x)
H = [28, 56, 84;
     56, 112, 168
     84, 168, 252]; 
end
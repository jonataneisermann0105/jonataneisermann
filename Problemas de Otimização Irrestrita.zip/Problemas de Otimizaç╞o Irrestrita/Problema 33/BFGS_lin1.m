%M�TODO QUASE-NEWTON BFGS APLICADO � FUN��O LINEAR - POSTO 1 [33]

%Inicializa��o:
n          = 3;
m          = 3;
option     = 3;
x          = [1,1,1]';
[fvec,J,f] = lin1(n,m,x,option);
g          = 2*[J]'*fvec;
a0         = 1;
r          = 0.9;
c          = 0.0001;                                                         %Constante da Condi��o de Armijo
H          = eye(n,n);                                                       %Aproxima��o da Inversa;
tol        = 1e-4;                                                           %Toler�ncia;
k          = 0;

%M�todo:
while norm(g)>tol
    p = -H*g;

    %Backtracking
    a = 1;
    
    %Valores antigos:
    [fvec,J,f] = lin1(n,m,x,option);
    fold       = f;
    
    %Valores Novos
    [fvec,J,f] = lin1(n,m,x+a*p,option);
    fnew       = f;
    
    while  fnew > fold + c*a*p'*p
        a = a*0.9;
        [fvec,J,f] = lin1(n,m,x+a*p,option);
        fnew       = f;
    end
    
    %C�lculo dos novos valores
    x          = x+a*p
    [fvec,J,f] = lin1(n,m,x,option);
    s          = a*p;
    g1         = 2*[J]'*fvec;
    y          = g1-g;
    t          = 1/(y'*s);
    H          = (eye(n,n)-t*s*y')*H*(eye(n,n)-t*y*s')+t*s*s';
    g          = g1;
    k          = k+1;
end
  x  
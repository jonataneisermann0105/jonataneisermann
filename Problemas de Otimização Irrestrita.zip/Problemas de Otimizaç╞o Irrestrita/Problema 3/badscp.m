%FUN��O POWELL BADLEY SCALED [3]:

% Dimens�es     -> n=2, m=2                      
% Ponto Inicial -> x=(0,1)          
% Minimizador   -> f=0 em (1.098...10-E5,9.106...)   

function [fvec,J,f] = badscp(n,m,x,option)

if (option==1 | option==3)
        fvec = @(x)[  10^4*x(1)*x(2)-1
                  exp(-x(1))+exp(-x(2))-1.0001  ] ;
              f = @(x)(10^4*x(1)*x(2)-1)^2 + (exp(-x(1))+exp(-x(2))-1.0001)^2;
end;
if (option==2 | option==3)
        J    = @(x)[  10^4*x(2)        10^4*x(1)
                    -exp(-x(1))      -exp(-x(2))  ] ;
end;

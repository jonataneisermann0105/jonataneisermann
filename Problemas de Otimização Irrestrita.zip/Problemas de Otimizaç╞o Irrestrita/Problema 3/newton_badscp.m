%M�TODO DE NEWTON APLICADO � FUN��O POWELL BADLEY SCALED [3]:
 
%Entradas do m�todo:
a0     = 1; 
r      = 0.9;
c      = 0.0001;
tol    = 1e-4;
option = 3;
n      = 2;
m      = 2;
x      = [0,1]';
option = 3;
itmax  = 5*10^4;

%Fun��o 
[fvec,J,f] = badscp(n,m,x,option);
  
g = 2*[J(x)]'*fvec(x);

%Hessiana 
[H] = hessiana(x);    

%M�todo:

k = 0;
while norm(g) > tol                 %primeiro crit�rio de parada

    if k > itmax                % segundo crit�rio de parada
        flag = -1;
        fprintf('n�mero m�ximo de itera��es atingido!\n')
        return
    end
    
    
    p = H\-g;
    
   
    %Garantia de Dire��o de Descida
    if g'*p >=0 
        p = -g;
    end
    
    %Condi��o de Armijo
    a = a0;
    j = 1;
    while (f(x+a*p)>=f(x)+c*a*g'*p)
        a=r*a;
        j = j + 1;  
    end

    %C�lculo dos novos valores
    x          = x+a*p
    [fvec,J,f] = badscp(n,m,x,option);
    g          = 2*[J(x)]'*fvec(x);
    [H]        = hessiana(x);
    k          = k + 1;
end

disp(['O metodo convergiu em ', num2str(k), ' iteracoes.'])
disp('Solucao: ')
x

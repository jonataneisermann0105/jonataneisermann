%M�TODO DO GRADIENTE APLICADO � FUN��O POWELL BADLEY SCALED [3]:

n          = 2;
m          = 2;
option     = 3;
x          = [0,1]';
[fvec,J,f] = badscp(n,m,x,option); 
p          = -2*[J(x)]'*fvec(x);
c1         = 0.0001;
k          = 0;
tol        = 10^(-4);

while norm(p) >= tol
    
    alpha = 1;
    
    %Backtracking
    while  f(x+alpha*p) > f(x)+c1*alpha*p'*p
        alpha = alpha*0.9;
    end

  x          = x+alpha*p
  [fvec,J,f] = badscp(n,m,x,option);
  p          = -2*[J(x)]'*fvec(x);
  k          = k+1;
  
  
end
x

% FUN��O TRIGONOM�TRICA [26]

% Dimens�es     -> n=3, m=n.
% Ponto Inicial -> x=(1/n,..,1/n)
% Minimizador   -> f=0 


function [fvec,J,f] = trig(n,m,x,option)  

  zero=0.d0;
  one=1.d0;

  if option==1
      sum1 = zero;
      for i=1:n
        xi   = x(i);
        cxi  = cos(xi);
        sum1  = sum1 + cxi;
        fvec(i) = n + (i)*(one - cxi) - sin(xi);
      end
      fvec=fvec';
      fvec=fvec-sum1;
   
  elseif option==2
      for j=1:n
        xj  = x(j);
        sxj = sin(xj);
        for i=1:n
          J( i, j) = sxj;
        end
        J(j, j) =  (j+1)*sxj - cos(xj);
      end

  elseif option==3
      sum1 = zero;
      for i=1:n
        xi   = x(i);
        cxi  = cos(xi);
        sum1  = sum1 + cxi;
        fvec(i) = n + (i)*(one - cxi) - sin(xi);
      end
      fvec=fvec';
      fvec=fvec-sum1;
      f   = fvec'*fvec;

      for j=1:n
        xj  = x(j);
        sxj = sin(xj);
        for i=1:n
          J( i, j) = sxj;
        end
        J(j, j) =  (j+1)*sxj - cos(xj);
      end

  else error('Error: trig.m : invalid option')
  end
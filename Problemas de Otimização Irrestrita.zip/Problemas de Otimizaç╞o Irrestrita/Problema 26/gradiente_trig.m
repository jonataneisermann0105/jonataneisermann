%M�TODO DO GRADIENTE APLICADO � FUN��O TRIGONOM�TRICA[26]:

n          = 3;
m          = 3;
option     = 3;
x          = [1/3,1/3,1/3]';
[fvec,J,f] = trig(n,m,x,option); 
p          = -2*[J]'*fvec;
c1         = 0.0001;
k          = 0;
tol        = 10^(-4);

while norm(p) >= tol

    alpha = 1;
    
    %Valores antigos
    [fvec,J,f] = trig(n,m,x,option);
    fold       = f;
    
    %Valores Novos
    [fvec,J,f] = trig(n,m,x+alpha*p,option);
    fnew       = f;
    
    %Backtracking
    
    alpha = 1;
    
    while  fnew > fold + c1*alpha*p'*p
        alpha = alpha*0.9;
        [fvec,J,f] = trig(n,m,x+alpha*p,option);
        fnew       = f;
    end

  x          = x+alpha*p
  [fvec,J,f] = trig(n,m,x,option);
  p          = -2*[J]'*fvec;
  k          = k+1;
  
end
x

%M�TODO DO GRADIENTE CONJUGADO N�O-LINEAR APLICADO � FUN��O HELICAL VALLEY[7]:

n          = 3;
m          = 3;
option     = 3;
x          = [1/3,1/3,1/3]';
[fvec,J,f] = trig(n,m,x,option);
g          = 2*[J]'*fvec;
p          = -g;
tol        = 1e-4;
k          = 0;
a0         = 1;
c          = 0.0001; 
r          = 0.9;

while norm (g) > tol
    
    %Busca Linear / Condi��o de Armijo
    a = a0;
    
    %Valores antigos:
    [fvec,J,f] = trig(n,m,x,option);
    fold       = f;
    
    %Valores Novos
    [fvec,J,f] = trig(n,m,x+a*p,option);
    fnew       = f;
    
    while  fnew > fold + c*a*p'*p
        a = a*0.9;
        [fvec,J,f] = trig(n,m,x+a*p,option);
        fnew       = f;
    end
    
    %C�lculo dos novos valores:
    x          = x + a*p;
    [fvec,J,f] = trig(n,m,x,option);
    g1         = 2*[J]'*fvec;
    B          = (g1'*g1)/(g'*g);
    p          = -g1+B*p;
    g          = g1;
    k          = k+1;
end
x
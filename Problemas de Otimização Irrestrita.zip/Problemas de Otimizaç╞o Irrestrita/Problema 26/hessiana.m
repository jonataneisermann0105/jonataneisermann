%HESSIANA DA FUN��O TRIGONOM�TRICA [26]

function [H] = hessiana(x)
H = [-2*(-19*cos(x(1))+4*sin(2*x(1))-4*sin(x(1))+5*cos(2*x(1))+sin(x(2)+x(1))+cos(x(1))*sin(x(3))+sin(x(1))*cos(x(3))+6*cos(x(1))*cos(x(2))+7*cos(x(1))*cos(x(3))), 12*sin(x(1))*sin(x(2))-2*cos(x(1))*sin(x(2))-2*sin(x(1))*cos(x(2)), 14*sin(x(1))*sin(x(3))-2*cos(x(1))*sin(x(3))-2*sin(x(1))*cos(x(3));
    12*sin(x(1))*sin(x(2))-2*cos(x(1))*sin(x(2))-2*sin(x(1))*cos(x(2)), -2*(10*cos(2*x(2))-25*cos(x(2))-5*sin(x(2))+6*sin(2*x(2))+sin(x(1)+x(2))+cos(x(2))*sin(x(3))+sin(x(2))*cos(x(3))+6*cos(x(1))*cos(x(2))+8*cos(x(2))*cos(x(3))), 16*sin(x(2))*sin(x(3))-2*cos(x(2))*sin(x(3))-2*sin(x(2))*cos(x(3));
    14*sin(x(1))*sin(x(3))-2*cos(x(1))*sin(x(3))-2*sin(x(1))*cos(x(3)), 16*sin(x(2))*sin(x(3))-2*cos(x(2))*sin(x(3))-2*sin(x(2))*cos(x(3)), -2*(17*cos(2*x(3))-33*cos(x(3))-6*sin(x(3))+8*sin(2*x(3))+sin(x(1)+x(3))+cos(x(3))*sin(x(2))+sin(x(3))*cos(x(2))+7*cos(x(1))*cos(x(3))+8*cos(x(3))*cos(x(2)))]; 
end